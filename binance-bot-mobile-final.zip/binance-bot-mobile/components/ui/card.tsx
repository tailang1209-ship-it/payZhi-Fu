import { View, type ViewProps } from 'react-native';
import { cn } from '@/lib/utils';

export function Card({ className, ...props }: ViewProps) {
  return (
    <View
      className={cn(
        'rounded-lg bg-surface p-4 border border-border',
        className
      )}
      {...props}
    />
  );
}

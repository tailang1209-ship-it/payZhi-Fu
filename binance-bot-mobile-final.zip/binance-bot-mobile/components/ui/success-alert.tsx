import { View, Text, Pressable } from 'react-native';
import { useColors } from '@/hooks/use-colors';

interface SuccessAlertProps {
  message: string;
  onDismiss?: () => void;
}

export function SuccessAlert({ message, onDismiss }: SuccessAlertProps) {
  const colors = useColors();

  return (
    <View className="bg-success/10 border border-success rounded-lg p-3 flex-row justify-between items-center gap-2">
      <Text className="flex-1 text-sm text-success font-medium">{message}</Text>
      {onDismiss && (
        <Pressable
          onPress={onDismiss}
          style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
        >
          <Text className="text-success font-bold">✕</Text>
        </Pressable>
      )}
    </View>
  );
}

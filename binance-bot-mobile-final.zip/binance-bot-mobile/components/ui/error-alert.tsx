import { View, Text, Pressable } from 'react-native';
import { useColors } from '@/hooks/use-colors';

interface ErrorAlertProps {
  message: string;
  onDismiss?: () => void;
}

export function ErrorAlert({ message, onDismiss }: ErrorAlertProps) {
  const colors = useColors();

  return (
    <View className="bg-error/10 border border-error rounded-lg p-3 flex-row justify-between items-center gap-2">
      <Text className="flex-1 text-sm text-error font-medium">{message}</Text>
      {onDismiss && (
        <Pressable
          onPress={onDismiss}
          style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
        >
          <Text className="text-error font-bold">✕</Text>
        </Pressable>
      )}
    </View>
  );
}

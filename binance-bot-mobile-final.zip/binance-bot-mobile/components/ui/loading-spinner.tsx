import { View, ActivityIndicator } from 'react-native';
import { useColors } from '@/hooks/use-colors';

export function LoadingSpinner() {
  const colors = useColors();
  return (
    <View className="flex-1 justify-center items-center">
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}

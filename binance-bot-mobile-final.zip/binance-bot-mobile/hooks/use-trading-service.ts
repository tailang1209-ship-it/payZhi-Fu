import { useEffect, useState } from 'react';
import { BinanceClient } from '@/lib/services/binance-client';
import { OKXClient } from '@/lib/services/okx-client';
import AsyncStorage from '@react-native-async-storage/async-storage';

type Exchange = 'binance' | 'okx';

interface TradingState {
  exchange: Exchange;
  accountInfo: any;
  tickers: Record<string, any>;
  openOrders: any[];
  loading: boolean;
  error: string | null;
}

const initialState: TradingState = {
  exchange: 'binance',
  accountInfo: null,
  tickers: {},
  openOrders: [],
  loading: false,
  error: null,
};

export function useTradingService() {
  const [state, setState] = useState<TradingState>(initialState);
  const [binanceClient, setBinanceClient] = useState<BinanceClient | null>(null);
  const [okxClient, setOKXClient] = useState<OKXClient | null>(null);

  // 初始化客户端
  useEffect(() => {
    const initializeClients = async () => {
      try {
        const binanceKey = await AsyncStorage.getItem('BINANCE_API_KEY');
        const binanceSecret = await AsyncStorage.getItem('BINANCE_API_SECRET');
        const okxKey = await AsyncStorage.getItem('OKX_API_KEY');
        const okxSecret = await AsyncStorage.getItem('OKX_API_SECRET');
        const okxPass = await AsyncStorage.getItem('OKX_PASSPHRASE');

        if (binanceKey && binanceSecret) {
          setBinanceClient(
            new BinanceClient({
              apiKey: binanceKey,
              apiSecret: binanceSecret,
            })
          );
        }

        if (okxKey && okxSecret && okxPass) {
          setOKXClient(
            new OKXClient({
              apiKey: okxKey,
              apiSecret: okxSecret,
              passphrase: okxPass,
            })
          );
        }
      } catch (error) {
        console.error('Failed to initialize clients:', error);
      }
    };

    initializeClients();
  }, []);

  const getClient = () => {
    if (state.exchange === 'binance') {
      return binanceClient;
    } else {
      return okxClient;
    }
  };

  const fetchAccountInfo = async () => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const client = getClient();
      if (!client) {
        throw new Error('Client not initialized');
      }
      const accountInfo = await client.getAccountInfo();
      setState((prev) => ({ ...prev, accountInfo, loading: false }));
    } catch (error: any) {
      setState((prev) => ({
        ...prev,
        error: error.message,
        loading: false,
      }));
    }
  };

  const fetchTickers = async (symbols?: string[]) => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const client = getClient();
      if (!client) {
        throw new Error('Client not initialized');
      }

      let tickers: any[] = [];
      if (state.exchange === 'binance') {
        if (symbols && symbols.length > 0) {
          tickers = await Promise.all(
            symbols.map((symbol) =>
              (client as BinanceClient).getTickerPrice(symbol)
            )
          );
        } else {
          tickers = await (client as BinanceClient).getAllTickerPrices();
        }
      } else {
        tickers = await (client as OKXClient).getTickers('SPOT');
      }

      const tickersMap = tickers.reduce((acc, ticker) => {
        const key = state.exchange === 'binance' ? ticker.symbol : ticker.instId;
        acc[key] = ticker;
        return acc;
      }, {});

      setState((prev) => ({ ...prev, tickers: tickersMap, loading: false }));
    } catch (error: any) {
      setState((prev) => ({
        ...prev,
        error: error.message,
        loading: false,
      }));
    }
  };

  const fetchOpenOrders = async (symbol?: string) => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const client = getClient();
      if (!client) {
        throw new Error('Client not initialized');
      }
      const orders = await client.getOpenOrders(symbol);
      setState((prev) => ({ ...prev, openOrders: orders, loading: false }));
    } catch (error: any) {
      setState((prev) => ({
        ...prev,
        error: error.message,
        loading: false,
      }));
    }
  };

  const placeOrder = async (orderData: any) => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const client = getClient();
      if (!client) {
        throw new Error('Client not initialized');
      }
      const order = await client.placeOrder(orderData);
      await fetchOpenOrders();
      return order;
    } catch (error: any) {
      setState((prev) => ({
        ...prev,
        error: error.message,
        loading: false,
      }));
      throw error;
    }
  };

  const cancelOrder = async (symbol: string, orderId: string | number) => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const client = getClient();
      if (!client) {
        throw new Error('Client not initialized');
      }
      const result = await (client as any).cancelOrder(symbol, orderId);
      await fetchOpenOrders();
      return result;
    } catch (error: any) {
      setState((prev) => ({
        ...prev,
        error: error.message,
        loading: false,
      }));
      throw error;
    }
  };

  const switchExchange = (exchange: Exchange) => {
    setState((prev) => ({
      ...prev,
      exchange,
      accountInfo: null,
      tickers: {},
      openOrders: [],
    }));
  };

  return {
    ...state,
    fetchAccountInfo,
    fetchTickers,
    fetchOpenOrders,
    placeOrder,
    cancelOrder,
    switchExchange,
  };
}

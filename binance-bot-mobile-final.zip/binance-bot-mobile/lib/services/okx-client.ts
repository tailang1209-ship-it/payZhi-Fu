import axios, { AxiosInstance } from 'axios';
import * as crypto from 'crypto';

interface OKXConfig {
  apiKey: string;
  apiSecret: string;
  passphrase: string;
}

interface OKXAccount {
  totalEq: string;
  isoEq: string;
  adjEq: string;
  details: Array<{
    ccy: string;
    cashBal: string;
    usdValue: string;
  }>;
}

interface OKXTicker {
  instId: string;
  last: string;
  change24h: string;
  vol24h: string;
}

interface OKXOrderRequest {
  instId: string;
  tdMode: 'cash' | 'isolated' | 'cross';
  side: 'buy' | 'sell';
  ordType: 'market' | 'limit' | 'post_only' | 'fok' | 'ioc';
  sz: string;
  px?: string;
}

interface OKXOrder {
  ordId: string;
  instId: string;
  side: string;
  ordType: string;
  px: string;
  sz: string;
  accFillSz: string;
  state: string;
  cTime: string;
}

export class OKXClient {
  private client: AxiosInstance;
  private apiKey: string;
  private apiSecret: string;
  private passphrase: string;
  private baseUrl = 'https://www.okx.com/api/v5';

  constructor(config: OKXConfig) {
    this.apiKey = config.apiKey;
    this.apiSecret = config.apiSecret;
    this.passphrase = config.passphrase;
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  private generateSignature(
    timestamp: string,
    method: string,
    requestPath: string,
    body: string
  ): string {
    const message = timestamp + method + requestPath + body;
    return crypto
      .createHmac('sha256', this.apiSecret)
      .update(message)
      .digest('base64');
  }

  private async request(
    method: 'GET' | 'POST' | 'DELETE',
    path: string,
    params?: Record<string, any>,
    body?: Record<string, any>
  ) {
    try {
      const timestamp = new Date().toISOString();
      const bodyStr = body ? JSON.stringify(body) : '';
      const signature = this.generateSignature(timestamp, method, path, bodyStr);

      const config: any = {
        method,
        url: path,
        headers: {
          'OK-ACCESS-KEY': this.apiKey,
          'OK-ACCESS-SIGN': signature,
          'OK-ACCESS-TIMESTAMP': timestamp,
          'OK-ACCESS-PASSPHRASE': this.passphrase,
          'Content-Type': 'application/json',
        },
      };

      if (params) {
        config.params = params;
      }
      if (body) {
        config.data = body;
      }

      const response = await this.client(config);
      if (response.data.code !== '0') {
        throw new Error(response.data.msg);
      }
      return response.data.data;
    } catch (error: any) {
      throw new Error(
        `OKX API Error: ${error.response?.data?.msg || error.message}`
      );
    }
  }

  async getAccountInfo(): Promise<OKXAccount> {
    const result = await this.request('GET', '/account/balance');
    return result[0];
  }

  async getTicker(instId: string): Promise<OKXTicker> {
    const result = await this.request('GET', '/market/ticker', { instId });
    return result[0];
  }

  async getTickers(instType: string = 'SPOT'): Promise<OKXTicker[]> {
    return this.request('GET', '/market/tickers', { instType });
  }

  async placeOrder(order: OKXOrderRequest): Promise<OKXOrder> {
    const result = await this.request('POST', '/trade/order', undefined, order);
    return result[0];
  }

  async cancelOrder(instId: string, ordId: string): Promise<OKXOrder> {
    const result = await this.request('POST', '/trade/cancel-order', undefined, {
      instId,
      ordId,
    });
    return result[0];
  }

  async getOpenOrders(instId?: string): Promise<OKXOrder[]> {
    const params = instId ? { instId } : {};
    return this.request('GET', '/trade/orders-pending', params);
  }

  async getOrderHistory(instId: string, limit: number = 100): Promise<OKXOrder[]> {
    return this.request('GET', '/trade/orders-history-archive', {
      instId,
      limit: limit.toString(),
    });
  }

  async get24hStats(instId: string) {
    const result = await this.request('GET', '/market/ticker', { instId });
    return result[0];
  }
}

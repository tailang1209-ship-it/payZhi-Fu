import axios, { AxiosInstance } from 'axios';
import * as crypto from 'crypto';

interface BinanceConfig {
  apiKey: string;
  apiSecret: string;
}

interface AccountInfo {
  totalAssetOfBtc: string;
  totalLiabilityOfBtc: string;
  totalAssetOfUsdt: string;
  balances: Array<{
    asset: string;
    free: string;
    locked: string;
  }>;
}

interface TickerPrice {
  symbol: string;
  price: string;
}

interface OrderRequest {
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'LIMIT' | 'MARKET';
  timeInForce?: 'GTC' | 'IOC' | 'FOK';
  quantity: string;
  price?: string;
}

interface Order {
  orderId: number;
  symbol: string;
  side: string;
  type: string;
  price: string;
  origQty: string;
  executedQty: string;
  status: string;
  time: number;
}

export class BinanceClient {
  private client: AxiosInstance;
  private apiKey: string;
  private apiSecret: string;
  private baseUrl = 'https://api.binance.com/api';

  constructor(config: BinanceConfig) {
    this.apiKey = config.apiKey;
    this.apiSecret = config.apiSecret;
    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: 10000,
    });
  }

  private generateSignature(queryString: string): string {
    return crypto
      .createHmac('sha256', this.apiSecret)
      .update(queryString)
      .digest('hex');
  }

  private async request(
    method: 'GET' | 'POST' | 'DELETE',
    endpoint: string,
    params?: Record<string, any>,
    signed: boolean = false
  ) {
    try {
      const config: any = {
        method,
        url: endpoint,
        headers: {
          'X-MBX-APIKEY': this.apiKey,
        },
      };

      if (signed) {
        const timestamp = Date.now();
        const queryParams = { ...params, timestamp: timestamp.toString() };
        const queryString = new URLSearchParams(queryParams).toString();
        const signature = this.generateSignature(queryString);
        config.params = { ...queryParams, signature };
      } else {
        config.params = params;
      }

      const response = await this.client(config);
      return response.data;
    } catch (error: any) {
      throw new Error(
        `Binance API Error: ${error.response?.data?.msg || error.message}`
      );
    }
  }

  async getAccountInfo(): Promise<AccountInfo> {
    return this.request('GET', '/v3/account', {}, true);
  }

  async getTickerPrice(symbol: string): Promise<TickerPrice> {
    return this.request('GET', '/v3/ticker/price', { symbol });
  }

  async getAllTickerPrices(): Promise<TickerPrice[]> {
    return this.request('GET', '/v3/ticker/price');
  }

  async placeOrder(order: OrderRequest): Promise<Order> {
    return this.request('POST', '/v3/order', order, true);
  }

  async cancelOrder(symbol: string, orderId: number): Promise<Order> {
    return this.request('DELETE', '/v3/order', { symbol, orderId }, true);
  }

  async getOpenOrders(symbol?: string): Promise<Order[]> {
    return this.request('GET', '/v3/openOrders', symbol ? { symbol } : {}, true);
  }

  async getOrderHistory(symbol: string, limit: number = 100): Promise<Order[]> {
    return this.request(
      'GET',
      '/v3/allOrders',
      { symbol, limit },
      true
    );
  }

  async get24hTickerStats(symbol: string) {
    return this.request('GET', '/v3/ticker/24hr', { symbol });
  }
}

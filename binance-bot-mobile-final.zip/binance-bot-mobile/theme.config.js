/** @type {const} */
const themeColors = {
  primary: { light: '#F0B90B', dark: '#F0B90B' },
  background: { light: '#FFFFFF', dark: '#0B0E11' },
  surface: { light: '#F5F5F5', dark: '#1E2329' },
  foreground: { light: '#11181C', dark: '#EAECEF' },
  muted: { light: '#687076', dark: '#8C92A0' },
  border: { light: '#E5E7EB', dark: '#2B3139' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };

import { ScrollView, Text, View, Pressable, Switch } from 'react-native';
import { useState, useEffect } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useColors } from '@/hooks/use-colors';
import { useColorScheme } from '@/hooks/use-color-scheme';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SettingsScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const [darkMode, setDarkMode] = useState(colorScheme === 'dark');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [apiConnected, setApiConnected] = useState(false);

  useEffect(() => {
    checkApiStatus();
  }, []);

  const checkApiStatus = async () => {
    const binanceKey = await AsyncStorage.getItem('BINANCE_API_KEY');
    const okxKey = await AsyncStorage.getItem('OKX_API_KEY');
    setApiConnected(!!(binanceKey || okxKey));
  };

  const handleThemeToggle = async (value: boolean) => {
    setDarkMode(value);
    const theme = value ? 'dark' : 'light';
    await AsyncStorage.setItem('theme', theme);
  };

  const handleNotificationsToggle = async (value: boolean) => {
    setNotificationsEnabled(value);
    await AsyncStorage.setItem('notifications_enabled', value ? 'true' : 'false');
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="p-4 gap-4">
          {/* 主题设置 */}
          <Card className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              外观
            </Text>
            <View className="flex-row justify-between items-center">
              <Text className="text-sm text-foreground">深色模式</Text>
              <Switch
                value={darkMode}
                onValueChange={handleThemeToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={darkMode ? colors.primary : colors.muted}
              />
            </View>
          </Card>

          {/* 通知设置 */}
          <Card className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              通知
            </Text>
            <View className="flex-row justify-between items-center">
              <Text className="text-sm text-foreground">启用通知</Text>
              <Switch
                value={notificationsEnabled}
                onValueChange={handleNotificationsToggle}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor={notificationsEnabled ? colors.primary : colors.muted}
              />
            </View>
            <Text className="text-xs text-muted">
              接收交易提醒和价格告警
            </Text>
          </Card>

          {/* API 连接状态 */}
          <Card className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              API 连接
            </Text>
            <View className="flex-row justify-between items-center">
              <Text className="text-sm text-foreground">连接状态</Text>
              <View
                className={`px-3 py-1 rounded-full ${
                  apiConnected ? 'bg-success' : 'bg-error'
                }`}
              >
                <Text className="text-xs font-semibold text-white">
                  {apiConnected ? '已连接' : '未连接'}
                </Text>
              </View>
            </View>
            <Text className="text-xs text-muted">
              {apiConnected
                ? '您的 API 密钥已配置'
                : '请在应用设置中配置 API 密钥'}
            </Text>
          </Card>

          {/* 关于 */}
          <Card className="gap-2">
            <Text className="text-base font-semibold text-foreground">
              关于
            </Text>
            <View className="gap-2 py-2">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">版本</Text>
                <Text className="text-sm text-foreground">1.0.0</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">应用名称</Text>
                <Text className="text-sm text-foreground">Binance Bot</Text>
              </View>
            </View>
          </Card>

          {/* 帮助和反馈 */}
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            className="rounded-lg p-4 border border-border"
          >
            <Text className="text-center text-sm font-semibold text-foreground">
              联系支持
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

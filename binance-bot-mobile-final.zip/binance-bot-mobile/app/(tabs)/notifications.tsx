import { ScrollView, Text, View, RefreshControl, FlatList, Pressable } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useColors } from '@/hooks/use-colors';

interface Notification {
  id: string;
  type: 'trade' | 'price' | 'system';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export default function NotificationsScreen() {
  const colors = useColors();
  const [refreshing, setRefreshing] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'trade',
      title: '交易执行',
      message: '成功买入 0.1 BTC @ 45000 USDT',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      read: false,
    },
    {
      id: '2',
      type: 'price',
      title: '价格告警',
      message: 'ETH 价格突破 2500 USDT',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      read: false,
    },
    {
      id: '3',
      type: 'system',
      title: '系统通知',
      message: '您的 API 连接已验证，所有功能正常',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      read: true,
    },
    {
      id: '4',
      type: 'trade',
      title: '交易执行',
      message: '成功卖出 1 ETH @ 2500 USDT',
      timestamp: new Date(Date.now() - 172800000).toISOString(),
      read: true,
    },
  ]);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setRefreshing(false);
  };

  const markAsRead = (id: string) => {
    setNotifications(
      notifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      )
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'trade':
        return '💱';
      case 'price':
        return '📈';
      case 'system':
        return '⚙️';
      default:
        return '📢';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'trade':
        return colors.success;
      case 'price':
        return colors.warning;
      case 'system':
        return colors.muted;
      default:
        return colors.foreground;
    }
  };

  const renderNotificationItem = ({ item }: { item: Notification }) => {
    const date = new Date(item.timestamp);
    const timeStr = date.toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
    });

    return (
      <Pressable
        onPress={() => markAsRead(item.id)}
        style={({ pressed }) => [
          {
            opacity: pressed ? 0.7 : 1,
          },
        ]}
      >
        <Card
          className={`gap-2 mb-2 ${
            !item.read ? 'border-l-4' : ''
          }`}
          style={!item.read ? { borderLeftColor: colors.primary } : {}}
        >
          <View className="flex-row justify-between items-start">
            <View className="flex-1 flex-row gap-3">
              <Text className="text-2xl">{getTypeIcon(item.type)}</Text>
              <View className="flex-1">
                <Text className="text-sm font-semibold text-foreground">
                  {item.title}
                </Text>
                <Text className="text-xs text-muted mt-1">
                  {item.message}
                </Text>
              </View>
            </View>
            <Text className="text-xs text-muted">{timeStr}</Text>
          </View>

          <View className="flex-row gap-2 pt-2 border-t border-border">
            {!item.read && (
              <Pressable
                onPress={() => markAsRead(item.id)}
                style={({ pressed }) => [
                  {
                    opacity: pressed ? 0.6 : 1,
                  },
                ]}
                className="flex-1"
              >
                <Text className="text-center text-xs font-semibold text-primary">
                  标记已读
                </Text>
              </Pressable>
            )}
            <Pressable
              onPress={() => deleteNotification(item.id)}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.6 : 1,
                },
              ]}
              className="flex-1"
            >
              <Text className="text-center text-xs font-semibold text-error">
                删除
              </Text>
            </Pressable>
          </View>
        </Card>
      </Pressable>
    );
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* 标题栏 */}
        <View className="p-4 border-b border-border flex-row justify-between items-center">
          <View>
            <Text className="text-lg font-bold text-foreground">
              通知中心
            </Text>
            {unreadCount > 0 && (
              <Text className="text-xs text-muted">
                {unreadCount} 条未读通知
              </Text>
            )}
          </View>
          {notifications.length > 0 && (
            <Pressable
              onPress={clearAll}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.6 : 1,
                },
              ]}
            >
              <Text className="text-xs font-semibold text-error">
                全部清除
              </Text>
            </Pressable>
          )}
        </View>

        {/* 通知列表 */}
        {notifications.length > 0 ? (
          <FlatList
            data={notifications}
            renderItem={renderNotificationItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ padding: 16, gap: 8 }}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                tintColor={colors.primary}
              />
            }
          />
        ) : (
          <View className="flex-1 justify-center items-center">
            <Text className="text-lg text-muted">暂无通知</Text>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}

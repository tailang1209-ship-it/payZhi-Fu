import { ScrollView, Text, View, RefreshControl, Pressable } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useTradingService } from '@/hooks/use-trading-service';
import { useColors } from '@/hooks/use-colors';
import { ErrorAlert } from '@/components/ui/error-alert';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function HomeScreen() {
  const colors = useColors();
  const { accountInfo, fetchAccountInfo, loading, error } = useTradingService();
  const [refreshing, setRefreshing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchAccountInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (error) {
      setErrorMsg(error);
    }
  }, [error]);

  const onRefresh = async () => {
    setRefreshing(true);
    setErrorMsg(null);
    await fetchAccountInfo();
    setRefreshing(false);
  };

  const totalAsset = accountInfo?.totalAssetOfUsdt || '0.00';
  const btcValue = accountInfo?.totalAssetOfBtc || '0.00';

  if (loading && !accountInfo) {
    return <LoadingSpinner />;
  }

  return (
    <ScreenContainer>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing || loading}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <View className="p-4 gap-4">
          {errorMsg && (
            <ErrorAlert
              message={errorMsg}
              onDismiss={() => setErrorMsg(null)}
            />
          )}
          {/* 总资产卡片 */}
          <Card className="gap-2">
            <Text className="text-sm text-muted">总资产</Text>
            <Text className="text-3xl font-bold text-foreground">
              ${parseFloat(totalAsset).toFixed(2)}
            </Text>
            <Text className="text-xs text-muted">
              ≈ {parseFloat(btcValue).toFixed(4)} BTC
            </Text>
          </Card>

          {/* 账户概览 */}
          <Card className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              账户概览
            </Text>
            {accountInfo?.balances && accountInfo.balances.length > 0 ? (
              accountInfo.balances
                .filter((b: any) => parseFloat(b.free) > 0 || parseFloat(b.locked) > 0)
                .slice(0, 5)
                .map((balance: any) => (
                  <View
                    key={balance.asset}
                    className="flex-row justify-between items-center py-2 border-t border-border"
                  >
                    <Text className="text-sm font-medium text-foreground">
                      {balance.asset}
                    </Text>
                    <View className="items-end">
                      <Text className="text-sm text-foreground">
                        {parseFloat(balance.free).toFixed(4)}
                      </Text>
                      {parseFloat(balance.locked) > 0 && (
                        <Text className="text-xs text-muted">
                          锁定: {parseFloat(balance.locked).toFixed(4)}
                        </Text>
                      )}
                    </View>
                  </View>
                ))
            ) : (
              <Text className="text-sm text-muted text-center py-4">
                加载中或暂无数据
              </Text>
            )}
          </Card>

          {/* 快速操作 */}
          <View className="gap-2">
            <Pressable
              style={({ pressed }) => [
                {
                  backgroundColor: colors.primary,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="rounded-lg p-3"
            >
              <Text className="text-center font-semibold text-black">
                开始交易
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { Text, View, RefreshControl, FlatList } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useTradingService } from '@/hooks/use-trading-service';
import { useColors } from '@/hooks/use-colors';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function AccountScreen() {
  const colors = useColors();
  const { accountInfo, fetchAccountInfo, loading } = useTradingService();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchAccountInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchAccountInfo();
    setRefreshing(false);
  };

  const totalAsset = accountInfo?.totalAssetOfUsdt || '0.00';
  const balances = accountInfo?.balances || [];
  const topBalances = balances
    .filter((b: any) => parseFloat(b.free) > 0 || parseFloat(b.locked) > 0)
    .sort((a: any, b: any) => parseFloat(b.free) - parseFloat(a.free))
    .slice(0, 10);

  const renderBalanceItem = ({ item }: { item: any }) => {
    const total = parseFloat(item.free) + parseFloat(item.locked);
    return (
      <View className="flex-row justify-between items-center p-3 border-b border-border">
        <View className="flex-1">
          <Text className="text-sm font-semibold text-foreground">
            {item.asset}
          </Text>
          <Text className="text-xs text-muted">
            可用: {parseFloat(item.free).toFixed(4)}
          </Text>
          {parseFloat(item.locked) > 0 && (
            <Text className="text-xs text-muted">
              锁定: {parseFloat(item.locked).toFixed(4)}
            </Text>
          )}
        </View>
        <Text className="text-sm font-semibold text-foreground">
          {total.toFixed(4)}
        </Text>
      </View>
    );
  };

  if (loading && !accountInfo) {
    return <LoadingSpinner />;
  }

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* 总资产卡片 */}
        <View className="p-4">
          <Card className="gap-2">
            <Text className="text-sm text-muted">总资产</Text>
            <Text className="text-4xl font-bold text-foreground">
              ${parseFloat(totalAsset).toFixed(2)}
            </Text>
          </Card>
        </View>

        {/* 余额列表 */}
        <View className="flex-1 border-t border-border">
          <View className="p-4 border-b border-border">
            <Text className="text-base font-semibold text-foreground">
              资产分布
            </Text>
          </View>
          {topBalances.length > 0 ? (
            <FlatList
              data={topBalances}
              renderItem={renderBalanceItem}
              keyExtractor={(item) => item.asset}
              scrollEnabled={false}
              refreshControl={
                <RefreshControl
                  refreshing={refreshing || loading}
                  onRefresh={onRefresh}
                  tintColor={colors.primary}
                />
              }
            />
          ) : (
            <View className="flex-1 justify-center items-center">
              <Text className="text-muted">加载中或暂无资产</Text>
            </View>
          )}
        </View>
      </View>
    </ScreenContainer>
  );
}

import { ScrollView, Text, View, RefreshControl, Pressable, Switch } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useColors } from '@/hooks/use-colors';

interface Strategy {
  id: string;
  name: string;
  type: string;
  status: 'running' | 'stopped';
  profit: number;
  trades: number;
  description: string;
}

export default function StrategiesScreen() {
  const colors = useColors();
  const [refreshing, setRefreshing] = useState(false);
  const [strategies, setStrategies] = useState<Strategy[]>([
    {
      id: '1',
      name: '网格交易',
      type: 'Grid Trading',
      status: 'running',
      profit: 1250.5,
      trades: 24,
      description: '在价格区间内自动买卖，获取波动收益',
    },
    {
      id: '2',
      name: '定投策略',
      type: 'DCA',
      status: 'running',
      profit: 850.2,
      trades: 12,
      description: '定期定额投资，平均成本',
    },
    {
      id: '3',
      name: '均线策略',
      type: 'MA Crossover',
      status: 'stopped',
      profit: -120.5,
      trades: 8,
      description: '基于移动平均线的趋势跟踪',
    },
  ]);

  const onRefresh = async () => {
    setRefreshing(true);
    // 模拟刷新
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setRefreshing(false);
  };

  const toggleStrategy = (id: string) => {
    setStrategies(
      strategies.map((s) =>
        s.id === id
          ? { ...s, status: s.status === 'running' ? 'stopped' : 'running' }
          : s
      )
    );
  };

  const renderStrategyCard = (strategy: Strategy) => {
    const isRunning = strategy.status === 'running';
    const isProfit = strategy.profit >= 0;

    return (
      <Card key={strategy.id} className="gap-3 mb-3">
        <View className="flex-row justify-between items-start">
          <View className="flex-1">
            <Text className="text-base font-semibold text-foreground">
              {strategy.name}
            </Text>
            <Text className="text-xs text-muted">{strategy.type}</Text>
          </View>
          <View
            className={`px-2 py-1 rounded-full ${
              isRunning ? 'bg-success' : 'bg-muted'
            }`}
          >
            <Text className="text-xs font-semibold text-white">
              {isRunning ? '运行中' : '已停止'}
            </Text>
          </View>
        </View>

        <Text className="text-sm text-muted">{strategy.description}</Text>

        <View className="gap-2 py-2 border-t border-b border-border">
          <View className="flex-row justify-between">
            <Text className="text-xs text-muted">累计收益</Text>
            <Text
              className={`text-sm font-bold ${
                isProfit ? 'text-success' : 'text-error'
              }`}
            >
              {isProfit ? '+' : ''}{strategy.profit.toFixed(2)} USDT
            </Text>
          </View>
          <View className="flex-row justify-between">
            <Text className="text-xs text-muted">交易次数</Text>
            <Text className="text-sm font-semibold text-foreground">
              {strategy.trades}
            </Text>
          </View>
        </View>

        <View className="flex-row justify-between items-center">
          <Text className="text-sm font-semibold text-foreground">
            {isRunning ? '停止' : '启动'}策略
          </Text>
          <Switch
            value={isRunning}
            onValueChange={() => toggleStrategy(strategy.id)}
            trackColor={{ false: colors.border, true: colors.success }}
            thumbColor={isRunning ? colors.success : colors.muted}
          />
        </View>

        <View className="flex-row gap-2">
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            className="flex-1 rounded-lg p-2 border border-border"
          >
            <Text className="text-center text-xs font-semibold text-foreground">
              编辑参数
            </Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.surface,
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            className="flex-1 rounded-lg p-2 border border-border"
          >
            <Text className="text-center text-xs font-semibold text-foreground">
              查看日志
            </Text>
          </Pressable>
        </View>
      </Card>
    );
  };

  return (
    <ScreenContainer>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <View className="p-4 gap-4">
          {/* 统计摘要 */}
          <Card className="gap-2">
            <Text className="text-base font-semibold text-foreground">
              策略概览
            </Text>
            <View className="gap-2 py-2">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">运行中的策略</Text>
                <Text className="text-sm font-bold text-success">
                  {strategies.filter((s) => s.status === 'running').length}
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">总收益</Text>
                <Text className="text-sm font-bold text-success">
                  +{strategies.reduce((sum, s) => sum + s.profit, 0).toFixed(2)} USDT
                </Text>
              </View>
            </View>
          </Card>

          {/* 创建新策略按钮 */}
          <Pressable
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            className="rounded-lg p-3"
          >
            <Text className="text-center font-semibold text-black">
              创建新策略
            </Text>
          </Pressable>

          {/* 策略列表 */}
          <View className="gap-2">
            <Text className="text-base font-semibold text-foreground">
              我的策略
            </Text>
            {strategies.map((strategy) => renderStrategyCard(strategy))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

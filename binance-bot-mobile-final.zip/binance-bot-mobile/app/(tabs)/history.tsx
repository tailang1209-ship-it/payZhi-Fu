import { ScrollView, Text, View, RefreshControl, Pressable } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useTradingService } from '@/hooks/use-trading-service';
import { useColors } from '@/hooks/use-colors';

interface TradeStats {
  totalTrades: number;
  totalProfit: number;
  winRate: number;
  largestWin: number;
  largestLoss: number;
}

export default function HistoryScreen() {
  const colors = useColors();
  const { exchange, loading } = useTradingService();
  const [refreshing, setRefreshing] = useState(false);
  const [trades, setTrades] = useState<any[]>([]);
  const [stats, setStats] = useState<TradeStats>({
    totalTrades: 0,
    totalProfit: 0,
    winRate: 0,
    largestWin: 0,
    largestLoss: 0,
  });
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);

  useEffect(() => {
    loadTradeHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [exchange]);

  const loadTradeHistory = async () => {
    // 模拟交易历史数据
    const mockTrades = [
      {
        id: '1',
        symbol: 'BTCUSDT',
        side: 'BUY',
        price: '45000',
        quantity: '0.1',
        total: '4500',
        profit: '500',
        date: new Date(Date.now() - 86400000).toISOString(),
      },
      {
        id: '2',
        symbol: 'ETHUSDT',
        side: 'SELL',
        price: '2500',
        quantity: '1',
        total: '2500',
        profit: '-100',
        date: new Date(Date.now() - 172800000).toISOString(),
      },
      {
        id: '3',
        symbol: 'BTCUSDT',
        side: 'BUY',
        price: '44000',
        quantity: '0.05',
        total: '2200',
        profit: '1000',
        date: new Date(Date.now() - 259200000).toISOString(),
      },
    ];

    setTrades(mockTrades);
    calculateStats(mockTrades);
  };

  const calculateStats = (tradeList: any[]) => {
    const totalTrades = tradeList.length;
    const totalProfit = tradeList.reduce((sum, t) => sum + parseFloat(t.profit), 0);
    const winCount = tradeList.filter((t) => parseFloat(t.profit) > 0).length;
    const winRate = totalTrades > 0 ? (winCount / totalTrades) * 100 : 0;
    const largestWin = Math.max(...tradeList.map((t) => parseFloat(t.profit)), 0);
    const largestLoss = Math.min(...tradeList.map((t) => parseFloat(t.profit)), 0);

    setStats({
      totalTrades,
      totalProfit,
      winRate,
      largestWin,
      largestLoss,
    });
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTradeHistory();
    setRefreshing(false);
  };

  const filteredTrades = selectedSymbol
    ? trades.filter((t) => t.symbol === selectedSymbol)
    : trades;

  const renderTradeItem = ({ item }: { item: any }) => {
    const isProfit = parseFloat(item.profit) > 0;
    const date = new Date(item.date);
    const dateStr = date.toLocaleDateString('zh-CN');

    return (
      <Card className="gap-2 mb-2">
        <View className="flex-row justify-between items-start">
          <View className="flex-1">
            <Text className="text-sm font-semibold text-foreground">
              {item.symbol}
            </Text>
            <Text
              className={`text-xs font-semibold ${
                item.side === 'BUY' ? 'text-success' : 'text-error'
              }`}
            >
              {item.side === 'BUY' ? '买入' : '卖出'} @ {item.price}
            </Text>
          </View>
          <View className="items-end">
            <Text
              className={`text-sm font-bold ${
                isProfit ? 'text-success' : 'text-error'
              }`}
            >
              {isProfit ? '+' : ''}{item.profit} USDT
            </Text>
            <Text className="text-xs text-muted">{dateStr}</Text>
          </View>
        </View>
        <View className="flex-row justify-between text-xs text-muted">
          <Text>数量: {item.quantity}</Text>
          <Text>总额: ${item.total}</Text>
        </View>
      </Card>
    );
  };

  return (
    <ScreenContainer>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing || loading}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <View className="p-4 gap-4">
          {/* 交易统计 */}
          <Card className="gap-3">
            <Text className="text-base font-semibold text-foreground">
              交易统计
            </Text>
            <View className="gap-2">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">总收益</Text>
                <Text
                  className={`text-sm font-bold ${
                    stats.totalProfit >= 0 ? 'text-success' : 'text-error'
                  }`}
                >
                  {stats.totalProfit >= 0 ? '+' : ''}{stats.totalProfit.toFixed(2)} USDT
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">交易次数</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {stats.totalTrades}
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">胜率</Text>
                <Text className="text-sm font-semibold text-foreground">
                  {stats.winRate.toFixed(1)}%
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">最大盈利</Text>
                <Text className="text-sm font-bold text-success">
                  +{stats.largestWin.toFixed(2)} USDT
                </Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">最大亏损</Text>
                <Text className="text-sm font-bold text-error">
                  {stats.largestLoss.toFixed(2)} USDT
                </Text>
              </View>
            </View>
          </Card>

          {/* 交易对筛选 */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">
              按交易对筛选
            </Text>
            <View className="flex-row gap-2 flex-wrap">
              <Pressable
                onPress={() => setSelectedSymbol(null)}
                style={({ pressed }) => [
                  {
                    backgroundColor: selectedSymbol === null ? colors.primary : colors.surface,
                    opacity: pressed ? 0.8 : 1,
                  },
                ]}
                className="rounded-lg px-3 py-2"
              >
                <Text
                  className={`text-xs font-semibold ${
                    selectedSymbol === null ? 'text-black' : 'text-foreground'
                  }`}
                >
                  全部
                </Text>
              </Pressable>
              {[...new Set(trades.map((t) => t.symbol))].map((symbol) => (
                <Pressable
                  key={symbol}
                  onPress={() => setSelectedSymbol(symbol as string)}
                  style={({ pressed }) => [
                    {
                      backgroundColor:
                        selectedSymbol === symbol ? colors.primary : colors.surface,
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                  className="rounded-lg px-3 py-2"
                >
                  <Text
                    className={`text-xs font-semibold ${
                      selectedSymbol === symbol ? 'text-black' : 'text-foreground'
                    }`}
                  >
                    {symbol}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* 交易历史列表 */}
          <View className="gap-2">
            <Text className="text-base font-semibold text-foreground">
              交易历史
            </Text>
            {filteredTrades.length > 0 ? (
              filteredTrades.map((trade) => (
                <View key={trade.id}>{renderTradeItem({ item: trade })}</View>
              ))
            ) : (
              <Card className="items-center py-8">
                <Text className="text-muted">暂无交易记录</Text>
              </Card>
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

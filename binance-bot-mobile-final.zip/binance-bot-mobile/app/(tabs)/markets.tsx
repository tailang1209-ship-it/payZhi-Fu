import { ScrollView, Text, View, RefreshControl, FlatList, Pressable, TextInput } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useTradingService } from '@/hooks/use-trading-service';
import { useColors } from '@/hooks/use-colors';
import { LoadingSpinner } from '@/components/ui/loading-spinner';

export default function MarketsScreen() {
  const colors = useColors();
  const { tickers, fetchTickers, loading, exchange, switchExchange } = useTradingService();
  const [refreshing, setRefreshing] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [filteredTickers, setFilteredTickers] = useState<any[]>([]);

  useEffect(() => {
    fetchTickers();
  }, [exchange]);

  useEffect(() => {
    const filtered = Object.values(tickers).filter((ticker: any) => {
      const symbol = exchange === 'binance' ? ticker.symbol : ticker.instId;
      return symbol.toLowerCase().includes(searchText.toLowerCase());
    });
    setFilteredTickers(filtered);
  }, [searchText, tickers]);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchTickers();
    setRefreshing(false);
  };

  const renderTickerItem = ({ item }: { item: any }) => {
    const symbol = exchange === 'binance' ? item.symbol : item.instId;
    const price = exchange === 'binance' ? item.price : item.last;
    const change = exchange === 'binance' ? '0' : item.change24h;
    const isPositive = parseFloat(change) >= 0;

    return (
      <Pressable
        style={({ pressed }) => [
          { opacity: pressed ? 0.7 : 1 },
        ]}
        className="flex-row justify-between items-center p-3 border-b border-border"
      >
        <View className="flex-1">
          <Text className="text-sm font-semibold text-foreground">{symbol}</Text>
          <Text className="text-xs text-muted">
            ${parseFloat(price).toFixed(2)}
          </Text>
        </View>
        <View className="items-end">
          <Text
            className={`text-sm font-semibold ${
              isPositive ? 'text-success' : 'text-error'
            }`}
          >
            {isPositive ? '+' : ''}{parseFloat(change).toFixed(2)}%
          </Text>
        </View>
      </Pressable>
    );
  };

  if (loading && Object.keys(tickers).length === 0) {
    return <LoadingSpinner />;
  }

  return (
    <ScreenContainer>
      <View className="flex-1">
        {/* 搜索和交易所切换 */}
        <View className="p-4 gap-3 border-b border-border">
          <TextInput
            placeholder="搜索交易对..."
            placeholderTextColor={colors.muted}
            value={searchText}
            onChangeText={setSearchText}
            className="bg-surface rounded-lg px-3 py-2 text-foreground border border-border"
          />
          <View className="flex-row gap-2">
            <Pressable
              onPress={() => switchExchange('binance')}
              style={({ pressed }) => [
                {
                  backgroundColor: exchange === 'binance' ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-2"
            >
              <Text
                className={`text-center font-semibold ${
                  exchange === 'binance' ? 'text-black' : 'text-foreground'
                }`}
              >
                Binance
              </Text>
            </Pressable>
            <Pressable
              onPress={() => switchExchange('okx')}
              style={({ pressed }) => [
                {
                  backgroundColor: exchange === 'okx' ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-2"
            >
              <Text
                className={`text-center font-semibold ${
                  exchange === 'okx' ? 'text-black' : 'text-foreground'
                }`}
              >
                OKX
              </Text>
            </Pressable>
          </View>
        </View>

        {/* 交易对列表 */}
        {filteredTickers.length > 0 ? (
          <FlatList
            data={filteredTickers}
            renderItem={renderTickerItem}
            keyExtractor={(item) => (exchange === 'binance' ? item.symbol : item.instId)}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                tintColor={colors.primary}
              />
            }
          />
        ) : (
          <View className="flex-1 justify-center items-center">
            <Text className="text-muted">
              {searchText ? '未找到匹配的交易对' : '暂无数据'}
            </Text>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}

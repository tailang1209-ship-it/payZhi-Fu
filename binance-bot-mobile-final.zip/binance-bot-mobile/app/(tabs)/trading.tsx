import { ScrollView, Text, View, Pressable, TextInput, FlatList, RefreshControl } from 'react-native';
import { useEffect, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { Card } from '@/components/ui/card';
import { useTradingService } from '@/hooks/use-trading-service';
import { useColors } from '@/hooks/use-colors';
import { ErrorAlert } from '@/components/ui/error-alert';
import { SuccessAlert } from '@/components/ui/success-alert';

export default function TradingScreen() {
  const colors = useColors();
  const { openOrders, fetchOpenOrders, placeOrder, cancelOrder, loading, error } =
    useTradingService();
  const [refreshing, setRefreshing] = useState(false);
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [price, setPrice] = useState('');
  const [quantity, setQuantity] = useState('');
  const [orderType, setOrderType] = useState<'LIMIT' | 'MARKET'>('LIMIT');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchOpenOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchOpenOrders();
    setRefreshing(false);
  };

  const handlePlaceOrder = async () => {
    if (!symbol.trim()) {
      setErrorMsg('请输入交易对');
      return;
    }
    if (!quantity || parseFloat(quantity) <= 0) {
      setErrorMsg('请输入有效的数量');
      return;
    }
    if (orderType === 'LIMIT' && (!price || parseFloat(price) <= 0)) {
      setErrorMsg('请输入有效的价格');
      return;
    }

    try {
      setErrorMsg(null);
      await placeOrder({
        symbol,
        side,
        type: orderType,
        quantity,
        price: orderType === 'LIMIT' ? price : undefined,
      });
      setPrice('');
      setQuantity('');
      setSuccessMsg(`成功${side === 'BUY' ? '买入' : '卖出'} ${quantity} ${symbol}`);
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (error: any) {
      setErrorMsg(`下单失败: ${error.message}`);
    }
  };

  const handleCancelOrder = async (orderId: string | number) => {
    try {
      setErrorMsg(null);
      await cancelOrder(symbol, orderId);
      setSuccessMsg('取消订单成功');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (error: any) {
      setErrorMsg(`取消订单失败: ${error.message}`);
    }
  };

  const total = price && quantity ? (parseFloat(price) * parseFloat(quantity)).toFixed(2) : '0.00';

  const renderOrderItem = ({ item }: { item: any }) => {
    const isPositive = item.side === 'BUY';
    return (
      <Card className="gap-2 mb-2">
        <View className="flex-row justify-between items-start">
          <View className="flex-1">
            <Text className="text-sm font-semibold text-foreground">
              {item.symbol}
            </Text>
            <Text
              className={`text-xs font-semibold ${
                isPositive ? 'text-success' : 'text-error'
              }`}
            >
              {item.side}
            </Text>
          </View>
          <Text className="text-sm font-semibold text-foreground">
            {item.origQty}
          </Text>
        </View>
        <View className="flex-row justify-between items-center">
          <Text className="text-xs text-muted">
            价格: {item.price}
          </Text>
          <Pressable
            onPress={() => handleCancelOrder(item.orderId)}
            style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
          >
            <Text className="text-xs text-error font-semibold">取消</Text>
          </Pressable>
        </View>
      </Card>
    );
  };

  return (
    <ScreenContainer>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing || loading}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <View className="p-4 gap-4">
          {errorMsg && (
            <ErrorAlert
              message={errorMsg}
              onDismiss={() => setErrorMsg(null)}
            />
          )}
          {successMsg && (
            <SuccessAlert
              message={successMsg}
              onDismiss={() => setSuccessMsg(null)}
            />
          )}
          {/* 交易对输入 */}
          <Card className="gap-2">
            <Text className="text-xs text-muted">交易对</Text>
            <TextInput
              placeholder="例如: BTCUSDT"
              placeholderTextColor={colors.muted}
              value={symbol}
              onChangeText={setSymbol}
              className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
            />
          </Card>

          {/* 买卖选择 */}
          <View className="flex-row gap-2">
            <Pressable
              onPress={() => setSide('BUY')}
              style={({ pressed }) => [
                {
                  backgroundColor: side === 'BUY' ? colors.success : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-3"
            >
              <Text
                className={`text-center font-semibold ${
                  side === 'BUY' ? 'text-white' : 'text-foreground'
                }`}
              >
                买入
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setSide('SELL')}
              style={({ pressed }) => [
                {
                  backgroundColor: side === 'SELL' ? colors.error : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-3"
            >
              <Text
                className={`text-center font-semibold ${
                  side === 'SELL' ? 'text-white' : 'text-foreground'
                }`}
              >
                卖出
              </Text>
            </Pressable>
          </View>

          {/* 订单类型 */}
          <View className="flex-row gap-2">
            <Pressable
              onPress={() => setOrderType('LIMIT')}
              style={({ pressed }) => [
                {
                  backgroundColor: orderType === 'LIMIT' ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-2"
            >
              <Text
                className={`text-center font-semibold ${
                  orderType === 'LIMIT' ? 'text-black' : 'text-foreground'
                }`}
              >
                限价
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setOrderType('MARKET')}
              style={({ pressed }) => [
                {
                  backgroundColor: orderType === 'MARKET' ? colors.primary : colors.surface,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className="flex-1 rounded-lg p-2"
            >
              <Text
                className={`text-center font-semibold ${
                  orderType === 'MARKET' ? 'text-black' : 'text-foreground'
                }`}
              >
                市价
              </Text>
            </Pressable>
          </View>

          {/* 价格和数量 */}
          {orderType === 'LIMIT' && (
            <Card className="gap-2">
              <Text className="text-xs text-muted">价格</Text>
              <TextInput
                placeholder="输入价格"
                placeholderTextColor={colors.muted}
                value={price}
                onChangeText={setPrice}
                keyboardType="decimal-pad"
                className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
              />
            </Card>
          )}

          <Card className="gap-2">
            <Text className="text-xs text-muted">数量</Text>
            <TextInput
              placeholder="输入数量"
              placeholderTextColor={colors.muted}
              value={quantity}
              onChangeText={setQuantity}
              keyboardType="decimal-pad"
              className="bg-background rounded-lg px-3 py-2 text-foreground border border-border"
            />
          </Card>

          {/* 总额 */}
          {orderType === 'LIMIT' && (
            <Card className="gap-2">
              <Text className="text-xs text-muted">总额</Text>
              <Text className="text-2xl font-bold text-foreground">
                ${total}
              </Text>
            </Card>
          )}

          {/* 下单按钮 */}
          <Pressable
            onPress={handlePlaceOrder}
            style={({ pressed }) => [
              {
                backgroundColor: colors.primary,
                opacity: pressed ? 0.8 : 1,
              },
            ]}
            className="rounded-lg p-4"
          >
            <Text className="text-center font-bold text-black text-base">
              {side === 'BUY' ? '买入' : '卖出'}
            </Text>
          </Pressable>

          {/* 未成交订单 */}
          {openOrders.length > 0 && (
            <View className="gap-2">
              <Text className="text-base font-semibold text-foreground">
                未成交订单
              </Text>
              {openOrders.map((order) => (
                <View key={order.orderId || order.ordId}>
                  {renderOrderItem({ item: order })}
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
